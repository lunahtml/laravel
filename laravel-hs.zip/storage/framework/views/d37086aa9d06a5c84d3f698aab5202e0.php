<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Resume</title>
</head>
<body>
    <h1>Edit Resume</h1>

    <form method="POST" action="<?php echo e(route('freelancer.resume.update', $resume->id)); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" value="<?php echo e($resume->title); ?>" required>
        </div>
        <div>
            <label for="content">Content:</label>
            <textarea id="content" name="content" rows="5" required><?php echo e($resume->content); ?></textarea>
        </div>
        <div>
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="draft" <?php echo e($resume->status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                <option value="published" <?php echo e($resume->status === 'published' ? 'selected' : ''); ?>>Published</option>
            </select>
        </div>
        <button type="submit">Update</button>
    </form>
</body>
</html>
<?php /**PATH /var/www/resources/views/freelancer/edit-resume.blade.php ENDPATH**/ ?>