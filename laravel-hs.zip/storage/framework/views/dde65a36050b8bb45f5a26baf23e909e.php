<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resumes</title>
</head>
<body>
    <h1>Resumes</h1>

    <?php if($resumes->isEmpty()): ?>
        <p>No resumes available.</p>
    <?php else: ?>
        <ul>
            <?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <h2><?php echo e($resume->title); ?></h2>
                    <p><?php echo e($resume->content); ?></p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</body>
</html>
<?php /**PATH /var/www/resources/views/resumes/index.blade.php ENDPATH**/ ?>