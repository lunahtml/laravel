<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freelancer Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(asset('js/skills.js')); ?>" defer></script>
</head>
<body>
    <h1>Welcome to your Freelancer Dashboard</h1>
    <p>Hello, <?php echo e(auth()->user()->name); ?>!</p>
    <p>Email: <?php echo e(auth()->user()->email); ?></p>
    <p>Role: <?php echo e(auth()->user()->role); ?></p>
    <p>Categories:</p>
<ul>
    <?php $__currentLoopData = auth()->user()->resumes->flatMap->categories->unique('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($category->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<p>Skills:</p>
<ul>
    <?php $__currentLoopData = auth()->user()->resumes->flatMap->skills->unique('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($skill->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


    <h2>Your Resumes</h2>
    <ul>
    <?php $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <strong><?php echo e($resume->title); ?></strong> - <?php echo e($resume->status); ?>

            <?php if($resume->file_path): ?>
                <br>
                <a href="<?php echo e(asset('storage/' . $resume->file_path)); ?>" target="_blank">Download File</a>
            <?php endif; ?>
            <br>
            <a href="<?php echo e(route('freelancer.resume.edit', $resume->id)); ?>">Edit</a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


    <h3>Create a New Resume</h3>
    <h1>Create a Resume</h1>
    <form method="POST" action="<?php echo e(route('freelancer.resume.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div>
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
    </div>
    <div>
        <label for="content">Content:</label>
        <textarea id="content" name="content" rows="5" required></textarea>
    </div>
    <div>
        <label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
        </select>
    </div>
    <div>
        <label for="file">Upload File:</label>
        <input type="file" id="file" name="file">
    </div>
    <div>
    <label for="category">Category:</label>
    <select id="category" name="category" required>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div>
    <label for="skills">Skills:</label>
    <input type="text" id="skill_input" placeholder="Enter a skill">
    <div id="skill_suggestions"></div>
    <div id="selected_skills"></div>
    <input type="hidden" id="skills_input" name="skills">
</div>
    <button type="submit">Create</button>
</form>

</body>
</html>
<?php /**PATH /var/www/resources/views/freelancer/dashboard.blade.php ENDPATH**/ ?>